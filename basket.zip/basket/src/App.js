import Sebet from "./components/Sebet";
import Shop from "./components/Shop";

function App() {
  return (
    <div className="App">
      <Shop />
      {/* <Sebet/> */}
    </div>
  );
}

export default App;
